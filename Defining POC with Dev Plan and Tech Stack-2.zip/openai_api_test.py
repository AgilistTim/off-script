#!/usr/bin/env python3
"""
OpenAI API Test Script

This script tests the OpenAI API connection and thread creation
to diagnose issues with the OffScript website chat integration.
"""

import requests
import json
import time

# API Key - Replace with your actual API key
API_KEY = "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"
ASSISTANT_ID = "asst_b6kBes7rHBC9gA4yJ9I5r5zm"

# Headers
headers = {
    "Content-Type": "application/json",
    "Authorization": f"Bearer {API_KEY}",
    "OpenAI-Beta": "assistants=v1"
}

def test_api_connection():
    """Test basic API connection"""
    print("Testing API connection...")
    try:
        response = requests.get(
            "https://api.openai.com/v1/models",
            headers=headers
        )
        if response.status_code == 200:
            print("✅ API connection successful")
            print(f"Status code: {response.status_code}")
            models = response.json()
            print(f"Available models: {len(models['data'])}")
            return True
        else:
            print("❌ API connection failed")
            print(f"Status code: {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Exception during API connection test: {str(e)}")
        return False

def test_assistant_retrieval():
    """Test retrieving the assistant"""
    print("\nTesting assistant retrieval...")
    try:
        response = requests.get(
            f"https://api.openai.com/v1/assistants/{ASSISTANT_ID}",
            headers=headers
        )
        if response.status_code == 200:
            print("✅ Assistant retrieval successful")
            print(f"Status code: {response.status_code}")
            assistant = response.json()
            print(f"Assistant name: {assistant.get('name', 'Unnamed')}")
            print(f"Assistant model: {assistant.get('model', 'Unknown')}")
            return True
        else:
            print("❌ Assistant retrieval failed")
            print(f"Status code: {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Exception during assistant retrieval: {str(e)}")
        return False

def test_thread_creation():
    """Test creating a thread"""
    print("\nTesting thread creation...")
    try:
        response = requests.post(
            "https://api.openai.com/v1/threads",
            headers=headers,
            json={}
        )
        if response.status_code == 200:
            print("✅ Thread creation successful")
            print(f"Status code: {response.status_code}")
            thread = response.json()
            thread_id = thread.get('id')
            print(f"Thread ID: {thread_id}")
            return thread_id
        else:
            print("❌ Thread creation failed")
            print(f"Status code: {response.status_code}")
            print(f"Response: {response.text}")
            return None
    except Exception as e:
        print(f"❌ Exception during thread creation: {str(e)}")
        return None

def test_message_creation(thread_id):
    """Test adding a message to a thread"""
    if not thread_id:
        print("Skipping message creation (no thread ID)")
        return False
    
    print("\nTesting message creation...")
    try:
        response = requests.post(
            f"https://api.openai.com/v1/threads/{thread_id}/messages",
            headers=headers,
            json={
                "role": "user",
                "content": "I enjoy working with computers and solving problems"
            }
        )
        if response.status_code == 200:
            print("✅ Message creation successful")
            print(f"Status code: {response.status_code}")
            message = response.json()
            print(f"Message ID: {message.get('id')}")
            return True
        else:
            print("❌ Message creation failed")
            print(f"Status code: {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Exception during message creation: {str(e)}")
        return False

def test_run_creation(thread_id):
    """Test creating a run"""
    if not thread_id:
        print("Skipping run creation (no thread ID)")
        return None
    
    print("\nTesting run creation...")
    try:
        response = requests.post(
            f"https://api.openai.com/v1/threads/{thread_id}/runs",
            headers=headers,
            json={
                "assistant_id": ASSISTANT_ID
            }
        )
        if response.status_code == 200:
            print("✅ Run creation successful")
            print(f"Status code: {response.status_code}")
            run = response.json()
            run_id = run.get('id')
            print(f"Run ID: {run_id}")
            return run_id
        else:
            print("❌ Run creation failed")
            print(f"Status code: {response.status_code}")
            print(f"Response: {response.text}")
            return None
    except Exception as e:
        print(f"❌ Exception during run creation: {str(e)}")
        return None

def test_run_status(thread_id, run_id):
    """Test checking run status"""
    if not thread_id or not run_id:
        print("Skipping run status check (missing thread ID or run ID)")
        return False
    
    print("\nTesting run status...")
    max_attempts = 10
    for attempt in range(max_attempts):
        try:
            response = requests.get(
                f"https://api.openai.com/v1/threads/{thread_id}/runs/{run_id}",
                headers=headers
            )
            if response.status_code == 200:
                run = response.json()
                status = run.get('status')
                print(f"Run status: {status} (attempt {attempt + 1}/{max_attempts})")
                
                if status in ['completed', 'failed', 'cancelled']:
                    if status == 'completed':
                        print("✅ Run completed successfully")
                        return True
                    else:
                        print(f"❌ Run ended with status: {status}")
                        print(f"Run details: {json.dumps(run, indent=2)}")
                        return False
                
                # Wait before checking again
                time.sleep(2)
            else:
                print(f"❌ Run status check failed (attempt {attempt + 1}/{max_attempts})")
                print(f"Status code: {response.status_code}")
                print(f"Response: {response.text}")
                return False
        except Exception as e:
            print(f"❌ Exception during run status check: {str(e)}")
            return False
    
    print("❌ Run did not complete within the expected time")
    return False

def test_messages_retrieval(thread_id):
    """Test retrieving messages from a thread"""
    if not thread_id:
        print("Skipping messages retrieval (no thread ID)")
        return False
    
    print("\nTesting messages retrieval...")
    try:
        response = requests.get(
            f"https://api.openai.com/v1/threads/{thread_id}/messages",
            headers=headers
        )
        if response.status_code == 200:
            print("✅ Messages retrieval successful")
            print(f"Status code: {response.status_code}")
            messages = response.json()
            print(f"Number of messages: {len(messages.get('data', []))}")
            
            # Print the content of the assistant's messages
            assistant_messages = [msg for msg in messages.get('data', []) if msg.get('role') == 'assistant']
            if assistant_messages:
                print("\nAssistant responses:")
                for msg in assistant_messages:
                    content = msg.get('content', [])
                    for item in content:
                        if item.get('type') == 'text':
                            print(f"- {item.get('text', {}).get('value', 'No text')}")
            else:
                print("No assistant messages found")
            
            return True
        else:
            print("❌ Messages retrieval failed")
            print(f"Status code: {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Exception during messages retrieval: {str(e)}")
        return False

def run_full_test():
    """Run a complete test of the OpenAI API integration"""
    print("=== STARTING OPENAI API INTEGRATION TEST ===\n")
    
    # Test API connection
    if not test_api_connection():
        print("\n❌ Test failed at API connection stage")
        return
    
    # Test assistant retrieval
    if not test_assistant_retrieval():
        print("\n❌ Test failed at assistant retrieval stage")
        return
    
    # Test thread creation
    thread_id = test_thread_creation()
    if not thread_id:
        print("\n❌ Test failed at thread creation stage")
        return
    
    # Test message creation
    if not test_message_creation(thread_id):
        print("\n❌ Test failed at message creation stage")
        return
    
    # Test run creation
    run_id = test_run_creation(thread_id)
    if not run_id:
        print("\n❌ Test failed at run creation stage")
        return
    
    # Test run status
    if not test_run_status(thread_id, run_id):
        print("\n❌ Test failed at run status stage")
        return
    
    # Test messages retrieval
    if not test_messages_retrieval(thread_id):
        print("\n❌ Test failed at messages retrieval stage")
        return
    
    print("\n=== OPENAI API INTEGRATION TEST COMPLETED SUCCESSFULLY ===")
    print(f"Thread ID: {thread_id}")
    print(f"Run ID: {run_id}")
    print("\nThis test confirms that the OpenAI API integration is working correctly.")
    print("If the website is still experiencing issues, the problem may be related to:")
    print("1. Browser CORS restrictions")
    print("2. Frontend JavaScript implementation")
    print("3. Network connectivity in the browser environment")

if __name__ == "__main__":
    run_full_test()
