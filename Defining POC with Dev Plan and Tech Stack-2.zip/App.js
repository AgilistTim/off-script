// App.js - Main application file for OffScript enhanced website

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import HomePage from './components/HomePage';
import CareerCategorySelectionPage from './components/CareerCategorySelectionPage';
import InteractiveVideoExplorationPage from './components/InteractiveVideoExplorationPage';
import PersonalizedRecommendationsPage from './components/PersonalizedRecommendationsPage';
import AssessmentPage from './components/AssessmentPage';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/categories" element={<CareerCategorySelectionPage />} />
          <Route path="/video-exploration/:categoryId" element={<InteractiveVideoExplorationPage />} />
          <Route path="/video-exploration/:categoryId/:videoId" element={<InteractiveVideoExplorationPage />} />
          <Route path="/recommendations/:categoryId" element={<PersonalizedRecommendationsPage />} />
          <Route path="/assessment" element={<AssessmentPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
