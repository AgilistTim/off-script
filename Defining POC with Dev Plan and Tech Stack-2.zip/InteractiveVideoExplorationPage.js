import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getVideosForCategory, getVideoById, getQuestionsForVideo } from './validatedVideos';
import './InteractiveVideoExplorationPage.css';

const InteractiveVideoExplorationPage = () => {
  const { category = 'technology', videoId } = useParams();
  const navigate = useNavigate();
  
  const [videos, setVideos] = useState([]);
  const [currentVideo, setCurrentVideo] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [responses, setResponses] = useState({});
  const [videoLoaded, setVideoLoaded] = useState(false);
  const playerRef = useRef(null);
  const [playerReady, setPlayerReady] = useState(false);
  const [showReflection, setShowReflection] = useState(false);
  const [reflectionResponse, setReflectionResponse] = useState('');
  const [showNextButton, setShowNextButton] = useState(false);
  
  // Load videos for the selected category
  useEffect(() => {
    const categoryVideos = getVideosForCategory(category);
    setVideos(categoryVideos);
    
    // If no specific video is selected, use the first one
    if (!videoId && categoryVideos.length > 0) {
      navigate(`/explore/${category}/${categoryVideos[0].id}`);
    } else if (videoId) {
      const video = getVideoById(videoId);
      setCurrentVideo(video);
      setQuestions(getQuestionsForVideo(videoId));
    }
  }, [category, videoId, navigate]);

  // Handle reflection submission
  const handleReflectionSubmit = () => {
    if (reflectionResponse.trim()) {
      setResponses({
        ...responses,
        [currentVideo.id]: reflectionResponse
      });
      setShowNextButton(true);
    }
  };

  // Navigate to next video in the category
  const handleNextVideo = () => {
    const currentIndex = videos.findIndex(v => v.id === currentVideo.id);
    if (currentIndex < videos.length - 1) {
      navigate(`/explore/${category}/${videos[currentIndex + 1].id}`);
    } else {
      // If this was the last video, go to recommendations
      navigate('/recommendations', { 
        state: { 
          responses,
          category
        } 
      });
    }
    setShowReflection(false);
    setReflectionResponse('');
    setShowNextButton(false);
  };

  // Toggle reflection panel
  const toggleReflection = () => {
    setShowReflection(!showReflection);
  };

  // Handle video error
  const handleVideoError = () => {
    console.error('Error loading video:', currentVideo?.id);
    // If current video fails, try to load the next one
    const currentIndex = videos.findIndex(v => v.id === currentVideo?.id);
    if (currentIndex < videos.length - 1) {
      navigate(`/explore/${category}/${videos[currentIndex + 1].id}`);
    }
  };

  return (
    <div className="video-exploration-container">
      <div className="category-header">
        <h2>{category.charAt(0).toUpperCase() + category.slice(1)} Careers</h2>
        <button onClick={() => navigate('/categories')} className="back-button">
          ← Back to Categories
        </button>
      </div>
      
      <div className="video-section">
        {currentVideo ? (
          <>
            <h3>{currentVideo.title}</h3>
            <div className="video-container">
              {/* Direct iframe embedding for more reliable playback */}
              <iframe
                src={`https://www.youtube.com/embed/${currentVideo.id}?rel=0&modestbranding=1`}
                title={currentVideo.title}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="youtube-player"
              ></iframe>
            </div>
            
            <div className="video-controls">
              <button 
                onClick={toggleReflection} 
                className="reflection-button"
              >
                {showReflection ? 'Hide Reflection' : 'Show Reflection Questions'}
              </button>
            </div>
            
            {showReflection && (
              <div className="reflection-panel">
                <h4>Reflect on what you've watched:</h4>
                <div className="questions-list">
                  {questions.map((question, index) => (
                    <p key={index} className="reflection-question">{question}</p>
                  ))}
                </div>
                <textarea
                  value={reflectionResponse}
                  onChange={(e) => setReflectionResponse(e.target.value)}
                  placeholder="Share your thoughts on these questions..."
                  className="reflection-input"
                />
                <button 
                  onClick={handleReflectionSubmit} 
                  className="submit-button"
                  disabled={!reflectionResponse.trim()}
                >
                  Submit Reflection
                </button>
                
                {showNextButton && (
                  <button 
                    onClick={handleNextVideo} 
                    className="next-button"
                  >
                    Next Video →
                  </button>
                )}
              </div>
            )}
          </>
        ) : (
          <div className="loading">Loading video...</div>
        )}
      </div>
      
      <div className="video-playlist">
        <h4>More {category.charAt(0).toUpperCase() + category.slice(1)} Videos:</h4>
        <div className="playlist-items">
          {videos.map((video) => (
            <div 
              key={video.id} 
              className={`playlist-item ${currentVideo && video.id === currentVideo.id ? 'active' : ''}`}
              onClick={() => navigate(`/explore/${category}/${video.id}`)}
            >
              <div className="playlist-item-title">{video.title}</div>
              <div className="playlist-item-duration">{video.duration}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default InteractiveVideoExplorationPage;
