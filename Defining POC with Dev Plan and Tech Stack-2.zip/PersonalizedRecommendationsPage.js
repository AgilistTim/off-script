import React from 'react';
import { Link, useParams } from 'react-router-dom';

// Career recommendations data
const careerRecommendations = {
  'tech': [
    {
      title: 'Software Developer',
      description: 'Based on your interest in problem-solving and creating impactful products, software development could be a great fit.',
      skills: ['Logical thinking', 'Creativity', 'Attention to detail', 'Communication'],
      pathways: ['Computer Science degree', 'Coding bootcamp', 'Self-taught with portfolio']
    },
    {
      title: 'UX/UI Designer',
      description: 'Your interest in visual interfaces and user experience suggests you might enjoy designing how users interact with technology.',
      skills: ['Visual design', 'Empathy', 'Research', 'Prototyping'],
      pathways: ['Design degree', 'UX bootcamp', 'Self-taught with portfolio']
    }
  ],
  'creative': [
    {
      title: 'Graphic Designer',
      description: 'Your appreciation for visual aesthetics and the creative process suggests graphic design could be a fulfilling path.',
      skills: ['Visual composition', 'Typography', 'Color theory', 'Software proficiency'],
      pathways: ['Design degree', 'Technical certification', 'Apprenticeship']
    },
    {
      title: 'Content Creator',
      description: 'Your interest in creating and sharing work with others aligns well with various content creation careers.',
      skills: ['Storytelling', 'Production', 'Audience engagement', 'Personal branding'],
      pathways: ['Communications degree', 'Self-taught with portfolio', 'Internships']
    }
  ],
  'trades': [
    {
      title: 'Plumber',
      description: 'Your interest in hands-on problem solving and helping others suggests plumbing could be a rewarding career.',
      skills: ['Technical knowledge', 'Problem-solving', 'Customer service', 'Physical dexterity'],
      pathways: ['Apprenticeship', 'Trade school', 'On-the-job training']
    },
    {
      title: 'Construction Manager',
      description: 'Your appreciation for seeing tangible results and coordinating projects could lead to success in construction management.',
      skills: ['Project planning', 'Leadership', 'Technical knowledge', 'Communication'],
      pathways: ['Construction Management degree', 'Working up from trades', 'Certificate programs']
    }
  ],
  'business': [
    {
      title: 'Marketing Specialist',
      description: 'Your interest in creative strategy and data analysis suggests marketing could be an excellent career path.',
      skills: ['Strategic thinking', 'Communication', 'Data analysis', 'Creativity'],
      pathways: ['Marketing degree', 'Digital marketing certifications', 'Entry-level marketing roles']
    },
    {
      title: 'Entrepreneur',
      description: 'Your drive for innovation and leadership could make entrepreneurship a fulfilling path.',
      skills: ['Risk management', 'Leadership', 'Problem-solving', 'Financial literacy'],
      pathways: ['Business degree', 'Startup incubators', 'Small business experience']
    }
  ],
  'healthcare': [
    {
      title: 'Registered Nurse',
      description: 'Your compassion and interest in direct patient care suggests nursing could be a rewarding career.',
      skills: ['Clinical knowledge', 'Empathy', 'Critical thinking', 'Communication'],
      pathways: ['Nursing degree (BSN)', 'Associate Degree in Nursing', 'Specialized certifications']
    },
    {
      title: 'Healthcare Administrator',
      description: 'Your organizational skills and interest in healthcare systems could make healthcare administration a good fit.',
      skills: ['Leadership', 'Healthcare knowledge', 'Financial management', 'Communication'],
      pathways: ['Healthcare Administration degree', 'Business degree with healthcare focus', 'Experience in healthcare settings']
    }
  ],
  'sustainability': [
    {
      title: 'Environmental Scientist',
      description: 'Your passion for research and environmental protection suggests environmental science could be fulfilling.',
      skills: ['Scientific analysis', 'Field research', 'Data collection', 'Report writing'],
      pathways: ['Environmental Science degree', 'Biology or Chemistry degree', 'Field research experience']
    },
    {
      title: 'Renewable Energy Technician',
      description: 'Your interest in hands-on work and sustainable technology suggests a career in renewable energy.',
      skills: ['Technical knowledge', 'Problem-solving', 'Safety awareness', 'Mechanical aptitude'],
      pathways: ['Technical certification', 'Associate degree in renewable energy', 'Apprenticeship programs']
    }
  ],
  'public': [
    {
      title: 'Teacher',
      description: 'Your passion for sharing knowledge and working with others suggests teaching could be a fulfilling career.',
      skills: ['Communication', 'Subject expertise', 'Adaptability', 'Empathy'],
      pathways: ['Education degree', 'Subject-specific degree with teaching credential', 'Alternative certification programs']
    },
    {
      title: 'Non-profit Program Manager',
      description: 'Your interest in making a difference and organizational skills suggests program management in the non-profit sector.',
      skills: ['Project management', 'Stakeholder engagement', 'Grant writing', 'Leadership'],
      pathways: ['Non-profit Management degree', 'Public Administration degree', 'Volunteer experience leading to roles']
    }
  ]
};

// Career category data
const careerCategories = {
  'tech': {
    title: 'Technology & Digital',
    color: 'from-blue-500 to-indigo-600',
  },
  'creative': {
    title: 'Creative & Media',
    color: 'from-purple-500 to-pink-600',
  },
  'trades': {
    title: 'Skilled Trades',
    color: 'from-cyan-500 to-blue-600',
  },
  'business': {
    title: 'Business & Entrepreneurship',
    color: 'from-amber-500 to-orange-600',
  },
  'healthcare': {
    title: 'Healthcare & Wellbeing',
    color: 'from-emerald-500 to-teal-600',
  },
  'sustainability': {
    title: 'Sustainability & Environment',
    color: 'from-green-500 to-emerald-600',
  },
  'public': {
    title: 'Public Service & Education',
    color: 'from-red-500 to-rose-600',
  }
};

const PersonalizedRecommendationsPage = () => {
  const { categoryId } = useParams();
  const category = careerCategories[categoryId] || careerCategories['trades'];
  const recommendations = careerRecommendations[categoryId] || careerRecommendations['trades'];
  
  const gradientClass = `bg-gradient-to-br ${category.color}`;

  return (
    <div className={`min-h-screen ${gradientClass} text-white flex flex-col items-center p-4 md:p-8`}>
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold mb-3">Your Personalized Recommendations</h1>
        <p className="text-xl text-white/80 max-w-2xl mx-auto">
          Based on your responses, here are some career paths in {category.title} that might resonate with you.
        </p>
      </header>

      <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        {recommendations.map((rec, index) => (
          <div key={index} className="bg-white/10 backdrop-blur-md p-6 rounded-lg shadow-xl">
            <h2 className="text-2xl font-bold mb-3">{rec.title}</h2>
            <p className="mb-4 text-white/90">{rec.description}</p>
            
            <div className="mb-4">
              <h3 className="text-lg font-semibold mb-2">Key Skills</h3>
              <div className="flex flex-wrap gap-2">
                {rec.skills.map((skill, i) => (
                  <span key={i} className="bg-white/20 px-3 py-1 rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-2">Potential Pathways</h3>
              <ul className="list-disc list-inside text-white/90">
                {rec.pathways.map((path, i) => (
                  <li key={i}>{path}</li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>

      <div className="w-full max-w-4xl bg-white/10 backdrop-blur-md p-6 rounded-lg shadow-xl mb-8">
        <h2 className="text-2xl font-bold mb-4">Next Steps</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/10 p-4 rounded-lg">
            <h3 className="text-xl font-semibold mb-2">Explore More Categories</h3>
            <p className="mb-3 text-white/90">Discover other career fields that might interest you.</p>
            <Link to="/categories" className="inline-block bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg transition duration-300">
              View All Categories
            </Link>
          </div>
          <div className="bg-white/10 p-4 rounded-lg">
            <h3 className="text-xl font-semibold mb-2">Take Assessment</h3>
            <p className="mb-3 text-white/90">Get personalized guidance through our AI career assistant.</p>
            <Link to="/assessment" className="inline-block bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg transition duration-300">
              Start Assessment
            </Link>
          </div>
          <div className="bg-white/10 p-4 rounded-lg">
            <h3 className="text-xl font-semibold mb-2">Save Your Results</h3>
            <p className="mb-3 text-white/90">Create an account to save your exploration journey.</p>
            <button className="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg transition duration-300">
              Create Account
            </button>
          </div>
        </div>
      </div>

      <Link to={`/video-exploration/${categoryId}`} className="text-white/80 hover:text-white transition duration-300">
        &larr; Back to Videos
      </Link>
    </div>
  );
};

export default PersonalizedRecommendationsPage;
