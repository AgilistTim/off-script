import React from 'react';
import { Link, useParams } from 'react-router-dom';

// Career category data structure
const careerCategories = [
  {
    id: 'tech',
    title: 'Technology & Digital',
    description: 'Explore careers in software development, IT support, digital marketing, and more.',
    iconPath: '/icons/tech-icon.svg',
    color: 'from-blue-500 to-indigo-600',
  },
  {
    id: 'creative',
    title: 'Creative & Media',
    description: 'Discover paths in design, content creation, video production, and entertainment.',
    iconPath: '/icons/creative-icon.svg',
    color: 'from-purple-500 to-pink-600',
  },
  {
    id: 'trades',
    title: 'Skilled Trades',
    description: 'Learn about careers in electrical, plumbing, construction, and other hands-on fields.',
    iconPath: '/icons/trades-icon.svg',
    color: 'from-cyan-500 to-blue-600',
  },
  {
    id: 'business',
    title: 'Business & Entrepreneurship',
    description: 'Discover opportunities in management, marketing, finance, and entrepreneurship.',
    iconPath: '/icons/business-icon.svg',
    color: 'from-amber-500 to-orange-600',
  },
  {
    id: 'healthcare',
    title: 'Healthcare & Wellbeing',
    description: 'Explore careers in medical care, mental health, fitness, and wellness.',
    iconPath: '/icons/healthcare-icon.svg',
    color: 'from-emerald-500 to-teal-600',
  },
  {
    id: 'sustainability',
    title: 'Sustainability & Environment',
    description: 'Discover careers in renewable energy, conservation, and environmental science.',
    iconPath: '/icons/sustainability-icon.svg',
    color: 'from-green-500 to-emerald-600',
  },
  {
    id: 'public',
    title: 'Public Service & Education',
    description: 'Learn about careers in teaching, government, non-profits, and community service.',
    iconPath: '/icons/public-icon.svg',
    color: 'from-red-500 to-rose-600',
  }
];

const CareerCategorySelectionPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-600 to-indigo-700 text-white flex flex-col items-center p-4 md:p-8">
      <header className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Explore Career Paths</h1>
        <p className="text-xl text-indigo-200 max-w-2xl mx-auto">
          Select a category that interests you to begin your exploration journey.
          Each path offers unique videos and insights to help you discover what resonates with you.
        </p>
      </header>

      <div className="w-full max-w-6xl grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {careerCategories.map((category) => (
          <Link 
            to={`/video-exploration/${category.id}`} 
            key={category.id}
            className={`bg-gradient-to-br ${category.color} hover:shadow-lg transform hover:-translate-y-1 transition-all duration-300 rounded-xl overflow-hidden`}
          >
            <div className="p-6 h-full flex flex-col">
              <div className="flex items-center mb-4">
                <div className="bg-white/20 p-3 rounded-full">
                  {/* Fallback icon if image doesn't load */}
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
                <h3 className="text-2xl font-bold ml-3">{category.title}</h3>
              </div>
              <p className="text-white/90 mb-4 flex-grow">{category.description}</p>
              <div className="flex justify-end">
                <span className="bg-white/20 px-4 py-2 rounded-lg text-sm font-medium">
                  Explore Path
                </span>
              </div>
            </div>
          </Link>
        ))}
      </div>

      <div className="mt-12 text-center">
        <p className="text-indigo-200 mb-4">Not sure where to start?</p>
        <Link 
          to="/assessment" 
          className="bg-white text-indigo-700 hover:bg-indigo-100 font-bold py-3 px-8 rounded-lg text-lg transition duration-300 shadow-lg"
        >
          Take Career Assessment
        </Link>
      </div>
      
      <div className="mt-8">
        <Link to="/" className="text-white/80 hover:text-white transition duration-300">
          &larr; Back to Home
        </Link>
      </div>
    </div>
  );
};

export default CareerCategorySelectionPage;
