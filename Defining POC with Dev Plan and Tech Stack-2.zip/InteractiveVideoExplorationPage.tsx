import React, { useState } from 'react';

const InteractiveVideoExplorationPage: React.FC = () => {
  const [promptVisible, setPromptVisible] = useState(false);
  const [showRecommendationLink, setShowRecommendationLink] = useState(false);
  const [currentPromptData, setCurrentPromptData] = useState<{ question: string; options: string[] } | null>(null);
  const [videoPlayed, setVideoPlayed] = useState(false);

  const videoId = "zci3Lw3FJKc"; // YouTube Video ID for "Day In The Life Of A Plumber | Changing Urinals"

  const prompts = [
    {
      question: "Watching the plumber identify and fix the urinal issue, what part of that process did you find most engaging or satisfying?",
      options: [
        "The challenge of diagnosing the problem.",
        "The hands-on process of fixing it.",
        "The moment it was successfully repaired.",
        "The problem-solving aspect in general."
      ]
    },
    {
      question: "Imagine yourself doing this kind of work. Which of these aspects would make you feel a sense of purpose or excitement?",
      options: [
        "Helping people directly with a practical need.",
        "The satisfaction of seeing a tangible result from your work.",
        "The independence and variety of tasks each day.",
        "The opportunity to use technical skills and tools."
      ]
    },
    {
      question: "After seeing a glimpse of a plumber's day, what's your initial feeling about this type of career?",
      options: [
        "Intrigued and want to know more.",
        "It seems like a valuable and skilled trade.",
        "Probably not the right fit for me.",
        "I admire the problem-solving involved."
      ]
    }
  ];

  const [currentPromptIndex, setCurrentPromptIndex] = useState(0);

  const handlePlayVideo = () => {
    setVideoPlayed(true);
    // Show first prompt after a short delay (simulating watching a bit of the video)
    setTimeout(() => {
      setCurrentPromptData(prompts[0]);
      setPromptVisible(true);
    }, 2000); // Adjust delay as needed
  };

  const handlePromptResponse = (response: string) => {
    console.log("User selected:", response); // In a real app, this would be saved
    setPromptVisible(false);
    const nextPromptIndex = currentPromptIndex + 1;
    if (nextPromptIndex < prompts.length) {
      setCurrentPromptIndex(nextPromptIndex);
      setTimeout(() => {
        setCurrentPromptData(prompts[nextPromptIndex]);
        setPromptVisible(true);
      }, 1000);
    } else {
      setShowRecommendationLink(true);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-600 to-cyan-400 text-white flex flex-col items-center justify-center p-4 md:p-8">
      <header className="text-center mb-8 md:mb-10">
        <h1 className="text-3xl md:text-4xl font-bold mb-3">Interactive Video: A Day as a Plumber</h1>
        <p className="text-md md:text-lg text-sky-100">Watch the video and reflect on what aspects resonate with you.</p>
      </header>

      <div className="w-full max-w-2xl bg-white/10 backdrop-blur-md p-6 md:p-8 rounded-lg shadow-xl">
        {!videoPlayed ? (
          <div className='flex flex-col items-center'>
             <img src={`https://img.youtube.com/vi/${videoId}/hqdefault.jpg`} alt="Video Thumbnail" className="w-full max-w-md rounded-md mb-6 shadow-lg"/>
            <button
              onClick={handlePlayVideo}
              className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded-lg text-lg transition duration-300 shadow-md mb-4"
            >
              Play Video: A Day as a Plumber
            </button>
            <p className='text-sm text-sky-200'>This demo will show a video snippet and then ask you some questions to understand your interests.</p>
          </div>
        ) : (
          <div className="mb-6 aspect-video">
            <iframe 
              width="100%" 
              height="315" 
              src={`https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1`} // Added autoplay and mute for better UX in a demo
              title="YouTube video player" 
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
              allowFullScreen
              className='rounded-md shadow-lg'
            ></iframe>
          </div>
        )}

        {promptVisible && videoPlayed && currentPromptData && (
          <div className="mt-6 p-4 bg-sky-700 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold mb-3 text-sky-100">{currentPromptData.question}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {currentPromptData.options.map((option, index) => (
                <button 
                  key={index} 
                  onClick={() => handlePromptResponse(option)} 
                  className="bg-sky-500 hover:bg-sky-600 text-white py-2 px-4 rounded-md transition duration-300 w-full"
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )}

        {showRecommendationLink && (
          <div className="mt-10 text-center">
            <p className="text-xl mb-4 text-sky-100">Thank you for your responses! Let's see what career paths might interest you.</p>
            <a
              href="#recommendations" // This would link to the recommendations page in a full app
              className="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-8 rounded-lg text-lg transition duration-300 shadow-lg"
            >
              View My Demo Recommendations
            </a>
          </div>
        )}
      </div>
      <div className="mt-8">
         <a href="#home" className="text-sky-200 hover:text-white transition duration-300">&larr; Back to Home (Demo)</a>
      </div>
    </div>
  );
};

export default InteractiveVideoExplorationPage;

