import React from 'react';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 to-blue-500 text-white flex flex-col items-center justify-center p-8">
      <header className="text-center mb-12">
        <h1 className="text-5xl font-bold mb-4">Welcome to OffScript</h1>
        <p className="text-xl text-purple-200 mb-8">Discover your path. Author your future. Find your purpose.</p>
        <p className="text-lg max-w-2xl mx-auto mb-8">
          OffScript is a revolutionary platform designed to help young people like you explore diverse career paths, understand your emotional resonance with different professions, and build a future you are truly passionate about. This demo showcases some of our core concepts.
        </p>
        <a
          href="#video-exploration" // This will be a link to the next section/page in a real app
          className="bg-white text-purple-600 font-bold py-3 px-8 rounded-lg text-lg hover:bg-purple-100 transition duration-300 shadow-lg"
        >
          Start Exploring (Demo)
        </a>
      </header>

      <section className="w-full max-w-4xl mt-10">
        <h2 className="text-3xl font-semibold text-center mb-8">What you can explore in this demo:</h2>
        <div className="grid md:grid-cols-3 gap-8 text-center">
          <div className="bg-white/20 p-6 rounded-lg shadow-xl">
            <h3 className="text-2xl font-semibold mb-3">Interactive Video Exploration</h3>
            <p className="text-purple-200">Experience how OffScript uses video content and reflective prompts to understand what truly excites you.</p>
          </div>
          <div className="bg-white/20 p-6 rounded-lg shadow-xl">
            <h3 className="text-2xl font-semibold mb-3">Personalized Recommendations</h3>
            <p className="text-purple-200">See how your interactions can lead to tailored career suggestions and actionable next steps.</p>
          </div>
          <div className="bg-white/20 p-6 rounded-lg shadow-xl">
            <h3 className="text-2xl font-semibold mb-3">Your Future Dashboard</h3>
            <p className="text-purple-200">Get a glimpse of your personalized dashboard, tracking your journey and showcasing potential futures.</p>
          </div>
        </div>
      </section>

      <footer className="mt-16 text-center text-purple-300">
        <p>&copy; 2025 OffScript. All Rights Reserved. (Demo Version)</p>
      </footer>
    </div>
  );
};

export default HomePage;

