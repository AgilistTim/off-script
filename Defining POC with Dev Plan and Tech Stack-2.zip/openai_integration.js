// OpenAI Assistant Integration for OffScript

// This file contains the implementation for integrating the OpenAI Assistant
// with the OffScript website, enabling conversational career guidance.

import React, { useState, useEffect, useRef } from 'react';

// OpenAI Assistant configuration
const ASSISTANT_ID = 'asst_b6kBes7rHBC9gA4yJ9I5r5zm';
const API_KEY = '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';

// Backend API for OpenAI communication
// This would be implemented as a serverless function or API route
export const sendMessageToAssistant = async (message, threadId = null) => {
  try {
    // In a real implementation, this would be a fetch to your backend API
    // that handles the OpenAI API calls securely
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message,
        threadId,
        assistantId: ASSISTANT_ID,
      }),
    });
    
    if (!response.ok) {
      throw new Error('Failed to communicate with assistant');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error sending message to assistant:', error);
    throw error;
  }
};

// React component for the chat interface
const CareerChatInterface = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [threadId, setThreadId] = useState(null);
  const messagesEndRef = useRef(null);

  // Add initial welcome message when component mounts
  useEffect(() => {
    setMessages([
      {
        role: 'assistant',
        content: "Hi there! I'm your OffScript Career Guide. I'm here to help you explore different career paths that might interest you. What kinds of activities or subjects do you enjoy spending time on?",
        timestamp: new Date()
      }
    ]);
  }, []);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle sending a message to the assistant
  const handleSendMessage = async () => {
    if (!input.trim()) return;
    
    // Add user message to chat
    const userMessage = {
      role: 'user',
      content: input,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    
    try {
      // Send message to assistant
      const response = await sendMessageToAssistant(input, threadId);
      
      // Save thread ID for continued conversation
      if (response.threadId && !threadId) {
        setThreadId(response.threadId);
      }
      
      // Add assistant response to chat
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: response.message,
        timestamp: new Date()
      }]);
    } catch (error) {
      console.error('Error getting response:', error);
      // Add error message
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "I'm sorry, I'm having trouble responding right now. Please try again in a moment.",
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full max-h-[600px] bg-white/10 backdrop-blur-md rounded-lg shadow-xl overflow-hidden">
      <div className="p-4 bg-indigo-600 text-white">
        <h2 className="text-xl font-semibold">Career Exploration Guide</h2>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, index) => (
          <div 
            key={index} 
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div 
              className={`max-w-[80%] p-3 rounded-lg ${
                msg.role === 'user' 
                  ? 'bg-indigo-500 text-white rounded-br-none' 
                  : 'bg-white/20 text-white rounded-bl-none'
              }`}
            >
              {msg.content}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white/20 text-white p-3 rounded-lg rounded-bl-none max-w-[80%]">
              <div className="flex space-x-2">
                <div className="w-2 h-2 rounded-full bg-white animate-bounce"></div>
                <div className="w-2 h-2 rounded-full bg-white animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 rounded-full bg-white animate-bounce" style={{ animationDelay: '0.4s' }}></div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      
      <div className="p-4 border-t border-white/10">
        <div className="flex space-x-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Ask about career paths..."
            className="flex-1 bg-white/10 text-white placeholder-white/50 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
          />
          <button
            onClick={handleSendMessage}
            disabled={isLoading}
            className="bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-2 rounded-lg transition duration-200 disabled:opacity-50"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
};

export default CareerChatInterface;

// Backend API implementation (would be in a separate file)
// This is a Next.js API route example

/*
// pages/api/chat.js
import OpenAI from 'openai';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY, // Store in environment variables
});

// Store thread IDs for users (in a real app, this would be in a database)
const userThreads = {};

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { message, threadId, assistantId } = req.body;
    
    // Get or create thread ID
    let currentThreadId = threadId;
    if (!currentThreadId) {
      const thread = await openai.beta.threads.create();
      currentThreadId = thread.id;
    }

    // Add user message to thread
    await openai.beta.threads.messages.create(currentThreadId, {
      role: 'user',
      content: message,
    });

    // Run the assistant on the thread
    const run = await openai.beta.threads.runs.create(currentThreadId, {
      assistant_id: assistantId,
    });

    // Poll for the run to complete
    let runStatus = await openai.beta.threads.runs.retrieve(currentThreadId, run.id);
    
    // Simple polling mechanism (in production, use a more sophisticated approach)
    while (runStatus.status !== 'completed') {
      if (runStatus.status === 'failed' || runStatus.status === 'cancelled') {
        return res.status(500).json({ error: 'Assistant run failed' });
      }
      
      // Wait a bit before checking again
      await new Promise(resolve => setTimeout(resolve, 1000));
      runStatus = await openai.beta.threads.runs.retrieve(currentThreadId, run.id);
    }

    // Get messages from the thread
    const messages = await openai.beta.threads.messages.list(currentThreadId);
    
    // Find the latest assistant message
    const assistantMessages = messages.data.filter(msg => msg.role === 'assistant');
    if (assistantMessages.length === 0) {
      return res.status(500).json({ error: 'No response from assistant' });
    }
    
    const latestMessage = assistantMessages[0];
    const responseContent = latestMessage.content[0].type === 'text' 
      ? latestMessage.content[0].text.value 
      : 'I received your message but am unable to provide a text response.';

    return res.status(200).json({ 
      message: responseContent,
      threadId: currentThreadId
    });
  } catch (error) {
    console.error('Error processing request:', error);
    return res.status(500).json({ error: 'Error processing request' });
  }
}
*/
