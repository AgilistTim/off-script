import React from 'react';

interface Skill {
  name: string;
  level: number; // e.g., 1-5 or percentage
}

interface FutureJob {
  title: string;
  match_score: number; // e.g., percentage
  reason: string;
}

interface RoadmapMilestone {
  id: string;
  title: string;
  status: 'completed' | 'in_progress' | 'todo';
  description: string;
}

// Updated dashboard data to align with plumbing and practical trades
const dashboardData = {
  user_name: "Alex P.", // Mock user name
  aspirational_themes: ["Hands-on Problem Solving", "Practical Skill Mastery", "Community Service through Trades"],
  skills_in_development: [
    { name: "Basic Pipefitting", level: 40 },
    { name: "Fixture Installation", level: 30 },
    { name: "Safety Procedures", level: 65 },
    { name: "Blueprint Reading", level: 20 },
  ] as Skill[],
  suggested_future_jobs: [
    { title: "Licensed Plumber", match_score: 88, reason: "Strong resonance with problem-solving and tangible results." },
    { title: "HVAC Technician", match_score: 75, reason: "Applies similar mechanical aptitude and system understanding." },
    { title: "Construction Site Supervisor", match_score: 65, reason: "Potential for leadership if interested in broader project coordination." },
  ] as FutureJob[],
  roadmap_milestones: [
    { id: "m1", title: "Completed: Watched 'Day in the Life of a Plumber' Video", status: "completed", description: "Gained initial insight into the plumbing trade." },
    { id: "m2", title: "In Progress: Research Local Plumbing Apprenticeships", status: "in_progress", description: "Identifying entry points into the profession." },
    { id: "m3", title: "To Do: Talk to a Professional Plumber", status: "todo", description: "Seek an informational interview to learn more firsthand." },
    { id: "m4", title: "To Do: Explore a Basic DIY Plumbing Project", status: "todo", description: "Gain some hands-on experience with simple tasks." },
    { id: "m5", title: "To Do: Investigate Pre-Apprenticeship Training Options", status: "todo", description: "Look into foundational courses for trade skills." },
  ] as RoadmapMilestone[],
};

const DashboardPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-600 to-sky-700 text-white flex flex-col items-center p-4 md:p-8">
      <header className="text-center mb-8 md:mb-10">
        <h1 className="text-3xl md:text-4xl font-bold mb-3">Your OffScript Dashboard</h1>
        <p className="text-md md:text-lg text-green-100">Welcome back, {dashboardData.user_name}! Here’s your journey so far.</p>
      </header>

      <div className="w-full max-w-5xl grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Aspirations & Themes */}
        <div className="bg-white/10 backdrop-blur-md p-6 rounded-lg shadow-xl col-span-1 md:col-span-2 lg:col-span-1">
          <h2 className="text-2xl font-semibold mb-3 text-white">Your Resonant Themes</h2>
          <ul className="space-y-2 text-green-50">
            {dashboardData.aspirational_themes.map((theme, i) => <li key={i} className="p-2 bg-black/20 rounded text-sm">{theme}</li>)}
          </ul>
        </div>

        {/* Skills in Development */}
        <div className="bg-white/10 backdrop-blur-md p-6 rounded-lg shadow-xl">
          <h2 className="text-2xl font-semibold mb-4 text-white">Exploring Skills</h2>
          {dashboardData.skills_in_development.map(skill => (
            <div key={skill.name} className="mb-4">
              <div className="flex justify-between text-green-50 mb-1">
                <span className='text-sm'>{skill.name}</span>
                <span className='text-sm'>{skill.level}% Interest</span>
              </div>
              <div className="w-full bg-black/20 rounded-full h-2.5">
                <div className="bg-cyan-400 h-2.5 rounded-full" style={{ width: `${skill.level}%` }}></div>
              </div>
            </div>
          ))}
        </div>

        {/* Suggested Future Jobs */}
        <div className="bg-white/10 backdrop-blur-md p-6 rounded-lg shadow-xl">
          <h2 className="text-2xl font-semibold mb-4 text-white">Potential Paths</h2>
          <div className="space-y-3">
            {dashboardData.suggested_future_jobs.map(job => (
              <div key={job.title} className="p-3 bg-black/20 rounded">
                <h4 className="font-semibold text-md text-green-50">{job.title} <span className="text-xs text-cyan-300">({job.match_score}% Resonance)</span></h4>
                <p className="text-xs text-green-200 italic">{job.reason}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Dynamic Roadmap */}
        <div className="bg-white/10 backdrop-blur-md p-6 rounded-lg shadow-xl col-span-1 md:col-span-2 lg:col-span-3">
          <h2 className="text-2xl font-semibold mb-4 text-white">Your Exploration Roadmap</h2>
          <div className="space-y-4">
            {dashboardData.roadmap_milestones.map(milestone => (
              <div key={milestone.id} className={`p-4 rounded-md border-l-4 ${milestone.status === 'completed' ? 'border-cyan-400 bg-black/20' : milestone.status === 'in_progress' ? 'border-yellow-400 bg-black/10' : 'border-gray-400 bg-black/5'}`}>
                <h4 className="font-semibold text-lg text-green-50">{milestone.title}</h4>
                <p className="text-sm text-green-200 mb-1">Status: <span className={`font-medium ${milestone.status === 'completed' ? 'text-cyan-300' : milestone.status === 'in_progress' ? 'text-yellow-300' : 'text-gray-300'}`}>{milestone.status.replace("_", " ").toUpperCase()}</span></p>
                <p className="text-xs text-green-200">{milestone.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-10 text-center">
        <a href="#recommendations" className="text-green-200 hover:text-white transition duration-300">&larr; Back to Recommendations (Demo)</a>
      </div>
    </div>
  );
};

export default DashboardPage;

