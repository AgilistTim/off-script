import React from 'react';

interface Recommendation {
  id: string;
  title: string;
  reason: string;
  description: string;
  next_steps: {
    type: string;
    title: string;
    link?: string;
  }[];
}

// Updated recommendations to align with plumbing and practical trades
const recommendationsData: Recommendation[] = [
  {
    id: 'rec1',
    title: 'Career Path: Licensed Plumber',
    reason: 'Your engagement with the hands-on problem-solving and the satisfaction of repair in the video suggests this could be a fulfilling path.',
    description: 'Licensed plumbers install, repair, and maintain pipes, fixtures, and other plumbing equipment used for water distribution and wastewater disposal in residential, commercial, and industrial buildings.',
    next_steps: [
      { type: 'course', title: 'Explore Pre-Apprenticeship Plumbing Programs (Local Tech College - Mock Link)' },
      { type: 'video', title: 'Watch: "Advanced Pipefitting Techniques" (YouTube - Mock Link)' },
      { type: 'action', title: 'Try a simple DIY plumbing repair at home (e.g., fixing a leaky faucet) with guidance.' },
    ],
  },
  {
    id: 'rec2',
    title: 'Career Path: HVAC Technician',
    reason: 'If the technical skill and system-based thinking in the plumbing video appealed to you, HVAC offers similar challenges and rewards.',
    description: 'Heating, Ventilation, and Air Conditioning (HVAC) technicians work on heating, ventilation, cooling, and refrigeration systems that control the temperature and air quality in buildings.',
    next_steps: [
      { type: 'article', title: 'Read: "What Does an HVAC Technician Do?" (Online Career Portal - Mock Link)' },
      { type: 'explore', title: 'Look into local HVAC companies and their apprenticeship opportunities.' },
      { type: 'follow', title: 'Follow HVAC trade journals or online communities.' },
    ],
  },
  {
    id: 'rec3',
    title: 'Skill Development: Blueprint Reading & Technical Drawing',
    reason: 'Your interest in understanding how systems work and the problem-solving aspect points to the value of these foundational skills for many trades.',
    description: 'Learn to interpret technical drawings, schematics, and blueprints used in construction and various trades to understand project scope, materials, and installation requirements.',
    next_steps: [
      { type: 'course', title: 'Online Course: "Introduction to Blueprint Reading" (Mock Platform)' },
      { type: 'project', title: 'Find a simple blueprint online (e.g., a shed) and try to identify different components.' },
    ],
  },
];

const PersonalizedRecommendationsPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-500 to-cyan-600 text-white flex flex-col items-center p-4 md:p-8">
      <header className="text-center mb-8 md:mb-10">
        <h1 className="text-3xl md:text-4xl font-bold mb-3">Your Personalized Recommendations</h1>
        <p className="text-md md:text-lg text-teal-100">Based on your reflections from the plumbing video...</p>
      </header>

      <div className="w-full max-w-3xl space-y-6">
        {recommendationsData.map((rec) => (
          <div key={rec.id} className="bg-white/10 backdrop-blur-md p-6 rounded-lg shadow-xl">
            <h2 className="text-2xl font-semibold mb-2 text-white">{rec.title}</h2>
            <p className="text-sm text-teal-200 italic mb-3">{rec.reason}</p>
            <p className="mb-4 text-teal-50">{rec.description}</p>
            <h3 className="text-lg font-semibold mb-2 text-white">Suggested Next Steps:</h3>
            <ul className="list-disc list-inside space-y-1 text-teal-100">
              {rec.next_steps.map((step, index) => (
                <li key={index}>
                  <strong className="text-white">{step.type.charAt(0).toUpperCase() + step.type.slice(1)}:</strong> {step.title}
                  {step.link && <a href="#mocklink" className="text-purple-300 hover:text-purple-100 ml-2">(Explore)</a>}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-10 text-center space-x-4">
        <a
          href="#dashboard"
          className="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-lg text-lg transition duration-300 shadow-lg"
        >
          View My Demo Dashboard
        </a>
        <a href="#video-exploration" className="text-teal-200 hover:text-white transition duration-300">&larr; Explore Another Video (Demo)</a>
      </div>
    </div>
  );
};

export default PersonalizedRecommendationsPage;

