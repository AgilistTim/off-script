// Multiple Career Journey Implementation for OffScript

// This file contains the implementation for supporting multiple career journeys
// in the OffScript website, allowing users to explore different career categories.

import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';

// Career category data structure
const careerCategories = [
  {
    id: 'tech',
    title: 'Technology & Digital',
    description: 'Explore careers in software development, IT support, digital marketing, and more.',
    iconPath: '/icons/tech-icon.svg',
    color: 'from-blue-500 to-indigo-600',
    videos: [
      {
        id: 'tech-1',
        title: 'A Day as a Software Developer',
        description: 'Follow Sarah through her day as a full-stack developer at a tech startup.',
        youtubeId: 'eIrMbAQSU34',
        thumbnailUrl: 'https://img.youtube.com/vi/eIrMbAQSU34/hqdefault.jpg',
        prompts: [
          {
            id: 'tech-1-p1',
            question: 'Which aspect of software development shown in the video interests you most?',
            options: [
              'Problem-solving and logical thinking',
              'Creating visual interfaces that users interact with',
              'Working collaboratively with a team',
              'Building something that impacts many people'
            ]
          },
          {
            id: 'tech-1-p2',
            question: 'How do you feel about the balance of independent work and collaboration shown?',
            options: [
              'I prefer more independent work time',
              'I like the mix of solo work and team collaboration',
              'I would want more team interaction',
              'I\'m not sure if this environment would suit me'
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'creative',
    title: 'Creative & Media',
    description: 'Discover paths in design, content creation, video production, and entertainment.',
    iconPath: '/icons/creative-icon.svg',
    color: 'from-purple-500 to-pink-600',
    videos: [
      {
        id: 'creative-1',
        title: 'Day in the Life of a Graphic Designer',
        description: 'Experience what it\'s like to work as a professional graphic designer.',
        youtubeId: 'cYuUlNg32gY',
        thumbnailUrl: 'https://img.youtube.com/vi/cYuUlNg32gY/hqdefault.jpg',
        prompts: [
          {
            id: 'creative-1-p1',
            question: 'Which part of the creative process shown in the video resonates with you most?',
            options: [
              'The initial concept and ideation phase',
              'The hands-on creation and development',
              'The refinement and perfecting of details',
              'The presentation and sharing of the final work'
            ]
          },
          {
            id: 'creative-1-p2',
            question: 'How important is creative freedom versus client direction in your ideal work environment?',
            options: [
              'I prefer complete creative freedom',
              'I like a balance of guidance and creative input',
              'I prefer clear direction with some creative flexibility',
              'I\'m comfortable following precise specifications'
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'trades',
    title: 'Skilled Trades',
    description: 'Learn about careers in electrical, plumbing, construction, and other hands-on fields.',
    iconPath: '/icons/trades-icon.svg',
    color: 'from-cyan-500 to-blue-600',
    videos: [
      {
        id: 'trades-1',
        title: 'A Day as a Plumber',
        description: 'Experience what it\'s like to work as a professional plumber solving real-world problems.',
        youtubeId: 'zci3Lw3FJKc',
        thumbnailUrl: 'https://img.youtube.com/vi/zci3Lw3FJKc/hqdefault.jpg',
        prompts: [
          {
            id: 'trades-1-p1',
            question: "Watching the plumber identify and fix the urinal issue, what part of that process did you find most engaging or satisfying?",
            options: [
              "The challenge of diagnosing the problem.",
              "The hands-on process of fixing it.",
              "The moment it was successfully repaired.",
              "The problem-solving aspect in general."
            ]
          },
          {
            id: 'trades-1-p2',
            question: "Imagine yourself doing this kind of work. Which of these aspects would make you feel a sense of purpose or excitement?",
            options: [
              "Helping people directly with a practical need.",
              "The satisfaction of seeing a tangible result from your work.",
              "The independence and variety of tasks each day.",
              "The opportunity to use technical skills and tools."
            ]
          }
        ]
      }
    ]
  }
];

// Career Category Selection Component
export const CareerCategorySelectionPage = () => {
  const [hoveredCategory, setHoveredCategory] = useState(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-600 to-indigo-700 text-white flex flex-col items-center p-4 md:p-8">
      <header className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Explore Career Paths</h1>
        <p className="text-xl text-indigo-200 max-w-2xl mx-auto">
          Select a category that interests you to begin your exploration journey.
          Each path offers unique videos and insights to help you discover what resonates with you.
        </p>
      </header>

      <div className="w-full max-w-5xl grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {careerCategories.map((category) => (
          <Link 
            to={`/video-exploration/${category.id}`} 
            key={category.id}
            className={`bg-gradient-to-br ${category.color} hover:shadow-lg transform hover:-translate-y-1 transition-all duration-300 rounded-xl overflow-hidden`}
            onMouseEnter={() => setHoveredCategory(category.id)}
            onMouseLeave={() => setHoveredCategory(null)}
          >
            <div className="p-6 h-full flex flex-col">
              <div className="flex items-center mb-4">
                <div className="bg-white/20 p-3 rounded-full">
                  <img src={category.iconPath} alt="" className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-bold ml-3">{category.title}</h3>
              </div>
              <p className="text-white/90 mb-4 flex-grow">{category.description}</p>
              <div className="flex justify-end">
                <span className="bg-white/20 px-4 py-2 rounded-lg text-sm font-medium">
                  Explore Path
                </span>
              </div>
            </div>
          </Link>
        ))}
      </div>

      <div className="mt-12 text-center">
        <p className="text-indigo-200 mb-4">Not sure where to start?</p>
        <Link 
          to="/assessment" 
          className="bg-white text-indigo-700 hover:bg-indigo-100 font-bold py-3 px-8 rounded-lg text-lg transition duration-300 shadow-lg"
        >
          Take Career Assessment
        </Link>
      </div>
    </div>
  );
};

// Video Exploration Component
export const InteractiveVideoExplorationPage = () => {
  const { categoryId, videoId } = useParams();
  const [promptVisible, setPromptVisible] = useState(false);
  const [showRecommendationLink, setShowRecommendationLink] = useState(false);
  const [currentPromptData, setCurrentPromptData] = useState(null);
  const [videoPlayed, setVideoPlayed] = useState(false);
  const [currentPromptIndex, setCurrentPromptIndex] = useState(0);
  
  // Get category data
  const category = careerCategories.find(cat => cat.id === categoryId) || careerCategories[2]; // Default to trades if not found
  
  // Get video data (first video if none specified)
  const video = videoId 
    ? category.videos.find(v => v.id === videoId) || category.videos[0]
    : category.videos[0];

  const handlePlayVideo = () => {
    setVideoPlayed(true);
    // Show first prompt after a short delay (simulating watching a bit of the video)
    setTimeout(() => {
      setCurrentPromptData(video.prompts[0]);
      setPromptVisible(true);
    }, 2000);
  };

  const handlePromptResponse = (response) => {
    console.log("User selected:", response); // In a real app, this would be saved
    setPromptVisible(false);
    const nextPromptIndex = currentPromptIndex + 1;
    if (nextPromptIndex < video.prompts.length) {
      setCurrentPromptIndex(nextPromptIndex);
      setTimeout(() => {
        setCurrentPromptData(video.prompts[nextPromptIndex]);
        setPromptVisible(true);
      }, 1000);
    } else {
      setShowRecommendationLink(true);
    }
  };

  // Generate gradient class based on category
  const gradientClass = `bg-gradient-to-br ${category.color}`;

  return (
    <div className={`min-h-screen ${gradientClass} text-white flex flex-col items-center p-4 md:p-8`}>
      <header className="text-center mb-8 md:mb-10">
        <h1 className="text-3xl md:text-4xl font-bold mb-3">Interactive Video: {video.title}</h1>
        <p className="text-md md:text-lg text-white/80">Watch the video and reflect on what aspects resonate with you.</p>
      </header>

      <div className="w-full max-w-2xl bg-white/10 backdrop-blur-md p-6 md:p-8 rounded-lg shadow-xl">
        {!videoPlayed ? (
          <div className='flex flex-col items-center'>
             <img src={video.thumbnailUrl} alt="Video Thumbnail" className="w-full max-w-md rounded-md mb-6 shadow-lg"/>
            <button
              onClick={handlePlayVideo}
              className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded-lg text-lg transition duration-300 shadow-md mb-4"
            >
              Play Video: {video.title}
            </button>
            <p className='text-sm text-white/80'>This demo will show a video snippet and then ask you some questions to understand your interests.</p>
          </div>
        ) : (
          <div className="mb-6 aspect-video">
            <iframe 
              width="100%" 
              height="315" 
              src={`https://www.youtube.com/embed/${video.youtubeId}?autoplay=1&mute=1`}
              title="YouTube video player" 
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
              allowFullScreen
              className='rounded-md shadow-lg'
            ></iframe>
          </div>
        )}

        {promptVisible && videoPlayed && currentPromptData && (
          <div className="mt-6 p-4 bg-white/20 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold mb-3 text-white">{currentPromptData.question}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {currentPromptData.options.map((option, index) => (
                <button 
                  key={index} 
                  onClick={() => handlePromptResponse(option)} 
                  className="bg-white/20 hover:bg-white/30 text-white py-2 px-4 rounded-md transition duration-300 w-full"
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )}

        {showRecommendationLink && (
          <div className="mt-10 text-center">
            <p className="text-xl mb-4 text-white/90">Thank you for your responses! Let's see what career paths might interest you.</p>
            <Link
              to={`/recommendations/${categoryId}`}
              className="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-8 rounded-lg text-lg transition duration-300 shadow-lg"
            >
              View My Recommendations
            </Link>
          </div>
        )}
      </div>
      <div className="mt-8 flex space-x-4">
         <Link to="/categories" className="text-white/80 hover:text-white transition duration-300">&larr; Back to Categories</Link>
         {category.videos.length > 1 && (
           <Link to={`/video-exploration/${categoryId}`} className="text-white/80 hover:text-white transition duration-300">Explore More Videos in {category.title} &rarr;</Link>
         )}
      </div>
    </div>
  );
};

// Recommendations Component
export const PersonalizedRecommendationsPage = () => {
  const { categoryId } = useParams();
  const category = careerCategories.find(cat => cat.id === categoryId) || careerCategories[2];
  
  // This would be dynamically generated based on user responses in a real implementation
  const recommendations = {
    'tech': [
      {
        title: 'Software Developer',
        description: 'Based on your interest in problem-solving and creating impactful products, software development could be a great fit.',
        skills: ['Logical thinking', 'Creativity', 'Attention to detail', 'Communication'],
        pathways: ['Computer Science degree', 'Coding bootcamp', 'Self-taught with portfolio']
      },
      {
        title: 'UX/UI Designer',
        description: 'Your interest in visual interfaces and user experience suggests you might enjoy designing how users interact with technology.',
        skills: ['Visual design', 'Empathy', 'Research', 'Prototyping'],
        pathways: ['Design degree', 'UX bootcamp', 'Self-taught with portfolio']
      }
    ],
    'creative': [
      {
        title: 'Graphic Designer',
        description: 'Your appreciation for visual aesthetics and the creative process suggests graphic design could be a fulfilling path.',
        skills: ['Visual composition', 'Typography', 'Color theory', 'Software proficiency'],
        pathways: ['Design degree', 'Technical certification', 'Apprenticeship']
      },
      {
        title: 'Content Creator',
        description: 'Your interest in creating and sharing work with others aligns well with various content creation careers.',
        skills: ['Storytelling', 'Production', 'Audience engagement', 'Personal branding'],
        pathways: ['Communications degree', 'Self-taught with portfolio', 'Internships']
      }
    ],
    'trades': [
      {
        title: 'Plumber',
        description: 'Your interest in hands-on problem solving and helping others suggests plumbing could be a rewarding career.',
        skills: ['Technical knowledge', 'Problem-solving', 'Customer service', 'Physical dexterity'],
        pathways: ['Apprenticeship', 'Trade school', 'On-the-job training']
      },
      {
        title: 'Construction Manager',
        description: 'Your appreciation for seeing tangible results and coordinating projects could lead to success in construction management.',
        skills: ['Project planning', 'Leadership', 'Technical knowledge', 'Communication'],
        pathways: ['Construction Management degree', 'Working up from trades', 'Certificate programs']
      }
    ]
  };

  const categoryRecommendations = recommendations[categoryId] || recommendations['trades'];
  const gradientClass = `bg-gradient-to-br ${category.color}`;

  return (
    <div className={`min-h-screen ${gradientClass} text-white flex flex-col items-center p-4 md:p-8`}>
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold mb-3">Your Personalized Recommendations</h1>
        <p className="text-xl text-white/80 max-w-2xl mx-auto">
          Based on your responses, here are some career paths in {category.title} that might resonate with you.
        </p>
      </header>

      <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        {categoryRecommendations.map((rec, index) => (
          <div key={index} className="bg-white/10 backdrop-blur-md p-6 rounded-lg shadow-xl">
            <h2 className="text-2xl font-bold mb-3">{rec.title}</h2>
            <p className="mb-4 text-white/90">{rec.description}</p>
            
            <div className="mb-4">
              <h3 className="text-lg font-semibold mb-2">Key Skills</h3>
              <div className="flex flex-wrap gap-2">
                {rec.skills.map((skill, i) => (
                  <span key={i} className="bg-white/20 px-3 py-1 rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-2">Potential Pathways</h3>
              <ul className="list-disc list-inside text-white/90">
                {rec.pathways.map((path, i) => (
                  <li key={i}>{path}</li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>

      <div className="w-full max-w-4xl bg-white/10 backdrop-blur-md p-6 rounded-lg shadow-xl mb-8">
        <h2 className="text-2xl font-bold mb-4">Next Steps</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/10 p-4 rounded-lg">
            <h3 className="text-xl font-semibold mb-2">Explore More Categories</h3>
            <p className="mb-3 text-white/90">Discover other career fields that might interest you.</p>
            <Link to="/categories" className="inline-block bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg transition duration-300">
              View All Categories
            </Link>
          </div>
          <div className="bg-white/10 p-4 rounded-lg">
            <h3 className="text-xl font-semibold mb-2">Take Assessment</h3>
            <p className="mb-3 text-white/90">Get personalized guidance through our AI career assistant.</p>
            <Link to="/assessment" className="inline-block bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg transition duration-300">
              Start Assessment
            </Link>
          </div>
          <div className="bg-white/10 p-4 rounded-lg">
            <h3 className="text-xl font-semibold mb-2">Save Your Results</h3>
            <p className="mb-3 text-white/90">Create an account to save your exploration journey.</p>
            <button className="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg transition duration-300">
              Create Account
            </button>
          </div>
        </div>
      </div>

      <Link to={`/video-exploration/${categoryId}`} className="text-white/80 hover:text-white transition duration-300">
        &larr; Back to Videos
      </Link>
    </div>
  );
};

export default {
  CareerCategorySelectionPage,
  InteractiveVideoExplorationPage,
  PersonalizedRecommendationsPage
};
